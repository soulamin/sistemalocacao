<?php

return [

    'breadcrumb' => 'القائمة',

];
